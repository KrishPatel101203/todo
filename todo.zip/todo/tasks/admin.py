from django.contrib import admin
from .models import Tasks

admin.site.register(Tasks)
